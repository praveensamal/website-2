<?php

session_start();
if(!isset($_SESSION['valid'])){

  header('location:index.php');
}
?>

<!DOCTYPE html>
<html>
<head>
	<title> Devices Registration </title>
	<link rel="stylesheet" type="text/css" href="css/style2.css">

	 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" crossorigin="anonymous">

    <!-- JS, Popper.js, and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" crossorigin="anonymous"></script>  
   
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <style>
       #field{
      width:60% !important;
    }
    form{
      margin: auto;
      width: 60%;
      -webkit-box-shadow: 4px 10px 6px -6px #777;
      -moz-box-shadow: 4px 10px 6px -6px #777;
      box-shadow: 4px 10px 6px 1px #c1c1c1;
      padding: 20px;
    }
  </style>
</head>
<body>
  
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand" href="#" style="color: #034EA2; font-family: Helvetica Black,sans-serif; font-weight:bold;"> SAMSUNG </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
         >
          <li class="nav-item active">
            <a class="nav-link" href="Devices.php">Register Devices</a>
          </li> 

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Update Devices Status
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="last.php"> Last User & Last Location </a>
              <a class="dropdown-item" href="update.php"> Time Period </a>
            </div>
          </li> 

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Search By
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="all.php"> All </a>
              <a class="dropdown-item" href="sample.php"> Sample ID </a>
              <a class="dropdown-item" href="devicetype.php"> Device Type </a>  
              <a class="dropdown-item" href="size.php"> Size </a>
              <a class="dropdown-item" href="model.php"> Model </a>
              <a class="dropdown-item" href="year.php"> Year </a>
            </div>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Delete device record
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="delete.php"> delete record </a>
            </div>
          </li> 

        </ul>

         <div class="navbar-collapse collapse w-50 order-3 dual-collapse2">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
            <a class="nav-link" href="logout.php">Logout</a>
          </li>
            </ul>
          </div>
        </ul>
      </div>
    </nav>

<br>
<br>
<div class="container">
<br><br>
<h2 style="font-family: malgun gothic;text-align:center;"> Update Time Period </h2>
    <br><br>
	<!-- Default form contact -->
<!-- <form class="text-center border border-light abc" action="device.php" method="post">

    <p class="h4 mb-4" style="font-size:40px;"> Device Registeration </p>

 
    <input type="text" id="defaultContactFormSample" class="form-control mb-4" name="sample" placeholder="Sample ID">

    
    <select class="browser-default custom-select mb-4" name="dropdown" id="dropdown">
        <option value="" disabled>Choose option</option>
        <option value="Panel" selected>Panel</option>
        <option value="2">Soundbar</option>
        <option value="3">PDM</option>
        <option value="4">MSPG</option>
        <option value="5">Network Speaker</option>
        <option value="6">Test Phone</option>
        <option value="7">Storage Devices</option>
        <option value="8">Other Devices</option>
    </select>


    
    <div class="row">
      <div class="col-md-5">
       <label> Model:</label>
      </div>
      <div class="col-md-5">
       <input type="text" id="defaultContactFormModel" class="form-control mb-4" name="model" placeholder="Model">
      </div>
    </div>

  
    <div class="row">
      <div class="col-md-5">
        <label>Year:</label>
      </div>
      <div class="col-md-5">
    <input type="text" id="defaultContactFormYear" class="form-control mb-4" name="year" placeholder="Year">
    </div>
  </div>
  
    <input type="text" id="defaultContactFormSize" class="form-control mb-4" name="size" placeholder="Size(in inches)"> 
    
    <input type="text" id="defaultContactFormOwner" class="form-control mb-4" name="owner" placeholder="Owner Name">   
    
    <input type="text" id="defaultContactFormUser" class="form-control mb-4" name="user" placeholder="Last User">
    
    <input type="text" id="defaultContactFormLocation" class="form-control mb-4" name="loc" placeholder="Last Location">
    
    <input type="text" id="defaultContactFormRemarks" class="form-control mb-4" name="remarks" placeholder="Remarks">
    
    <div class="center">
    <button class="btn btn-info btn-block" type="submit" style="width: 50%;">Send</button>
    </div>
</form> -->
      <form action="device.php" method="POST">
        <div class="form-group">
          <label for="sample" >Sample ID :</label>
          <input type="text" id="defaultContactFormSample" class="form-control" id="field" name="sample"  placeholder="Sample">
        </div>
        <div class="form-group">
          <label for="exampleFormControlSelect1">Device Type :</label>
          <select class="form-control" id="exampleFormControlSelect1" name="dropdown">
          <option value="" disabled>Choose option</option>
          <option value="Panel" selected>Panel</option>
          <option value="Soundbar">Soundbar</option>
          <option value="PDM">PDM</option>
          <option value="MSPG">MSPG</option>
          <option value="Network Speaker">Network Speaker</option>
          <option value="Test Phone">Test Phone</option>
          <option value="Storage Devices">Storage Devices</option>
          <option value="Other Devices">Other Devices</option>
          </select>
        </div>
        <div class="form-group">
          <label for="model" > Model :</label>
          <input type="text" id="defaultContactFormModel" class="form-control" id="field" name="model"  placeholder="Model" required>
        </div>
        <div class="form-group">
          <label for="user"> Year :</label>
          <input type="text" id="defaultContactFormYear" class="form-control" id="field" name="year" placeholder="Year" required>
        </div>
        <div class="form-group">
          <label for="user"> Size :</label>
          <input type="text" id="defaultContactFormSize"  class="form-control" id="field" name="size" placeholder="Size (In Inches)" required>
        </div>
        <div class="form-group">
          <label for="user">Owner Name :</label>
          <input type="text" id="defaultContactFormOwner" class="form-control" id="field" name="owner" placeholder="Owner Name" required>
        </div>
        <div class="form-group">
          <label for="user">Last User :</label>
          <input type="text" id="defaultContactFormUser" class="form-control" id="field" name="user" placeholder="Last User">
        </div>
        <div class="form-group">
          <label for="user">Last Location :</label>
          <input type="text" id="defaultContactFormLocation" class="form-control" id="field" name="loc" placeholder="Last Location">
        </div>
        <div class="form-group">
          <label for="user">Remarks :</label>
          <input type="text" id="defaultContactFormRemarks" class="form-control" id="field" name="remarks" placeholder="Remarks">
        </div>
        <input type="submit" id="defaultContactFormUser" class="btn btn-primary" name="update" value="Submit">
      </form>
<!-- Default Device Type Form -->
</div>
<br>
<br>

<div class="footer">
  <p> All Rights Reserved @ Samsung <br> For Queries Contact: p.samal@samsung.com

  </p>
</div>

<style>
.footer {
  
   position: relative;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
   height: 55px;
}
</style>
</body>
</html>
