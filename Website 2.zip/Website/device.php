<?php

session_start();
if(!isset($_SESSION['valid'])){

  header('location:index.php');
}
else
{
  $user_email = $_SESSION['user_email'];
}


$con= mysqli_connect("localhost","root","","login");

if($con){

echo "Connection Sucessful";
}else{
	echo "No Connection";
}

// mysqli_connect_db($con, 'login');

$sam=$_POST['sample'];

$drop=$_POST['dropdown'];

$mod=$_POST['model'];

$yr=$_POST['year'];

$siz=$_POST['size'];

$own=$_POST['owner'];

$use=$_POST['user'];

$loca=$_POST['loc'];

//$tipe=$_POST['period'];

$rem=$_POST['remarks'];







$q= "select * from register where sample = '$sam' && dropdown= '$drop' && model= '$mod' && year= '$yr' && size= '$siz' && owner= '$own' && user= '$use' && loc= '$loca' && remarks= '$rem' && user_email= '$user_email'";

$result=mysqli_query($con, $q);

$num=mysqli_num_rows($result);

if($num==1){
	echo '<script language="javascript">';
    echo 'alert("This sample no. already registered.");';
    echo 'window.location = "devices.php"';
    echo '</script>';
}else{

	$qy= "insert into register (sample,dropdown,model,year,size,owner,user,loc,remarks,user_email) VALUES ('$sam','$drop','$mod','$yr','$siz','$own','$use','$loca','$rem','$user_email')";
	
	if(mysqli_query($con,$qy))
	{
	echo '<script language="javascript">';
    echo 'alert("Data entered sucessfully.");';
    echo 'window.location = "devices.php"';
    echo '</script>';

	}
	else
	{
		echo "Error: " . $qy . "" . mysqli_error($con);
	}
}


?> 