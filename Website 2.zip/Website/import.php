<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" crossorigin="anonymous">

	<!-- JS, Popper.js, and jQuery -->
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>

	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" crossorigin="anonymous"></script>  

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>



</head>
<body>

	<div class="container">
		<div class="row" style="margin-top: 100px;">
			<div class="col-sm-12" style="text-align: center;"><h3>Import Excel Data</h3><br></div>
			<div class="col-sm-3"></div>
			<div class="col-sm-6">


				<?php

				session_start();
				if(!isset($_SESSION['valid'])){

					header('location:index.php');
				}
				else{

					$user_email = $_SESSION['user_email'];
				}

				$con= mysqli_connect("localhost","root","","login");
				if(isset($_POST["import"]))
				{

					$filename=$_FILES["file"]["tmp_name"];
					if ($_FILES["file"]["size"]>0) {
						$i = 0;
						
						$file=fopen($filename,"r");
						while ($line = fgets($file)) {
							if($i == 0)
							{
								echo "do nothng\n";
							}
							else
							{
							//echo($line);
								$str_arr = explode (",", $line); 
								//print_r($str_arr); 

								$q= "select * from register where sample = '$str_arr[0]' && user_email= '$user_email'";

								$result=mysqli_query($con, $q);

								$num=mysqli_num_rows($result);

								if($num==1){


								}else{
									$sql= "INSERT INTO register(sample,size,owner,user_email) VALUES ('" . $str_arr[0] ."','" . $str_arr[1] ."','" . $str_arr[2] ."','$user_email')";
									mysqli_query($con,$sql);

								}
							}
							$i++;
						}
						fclose($file);

						#echo "<p style='color:green'>ALL DATA inserted sucessfully</p>";
						# code...
						echo '<script language="javascript">';
						echo 'alert("Data imported sucessfully.");';
						echo 'window.location = "all.php"';
						echo '</script>';
					}


				}

				?>




				<form method="POST" action="" enctype="multipart/form-data">
					<input type="file" name="file" class="form-control"><br>
					<input type="submit" value="upload data" class="btn btn-primary" name="import">
				</form>
			</div>
			<div class="col-sm-3"></div>
		</div>
	</body>
	</html>