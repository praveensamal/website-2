<?php

$con= mysqli_connect("localhost","root","","login");
if(!$con){
	die('Could not connect mysql:' .mysql_error());
}

$limit = 100;  
if (isset($_GET["page"])) {
	$page  = $_GET["page"]; 
	} 
	else{ 
	$page=1;
	};  
$start_from = ($page-1) * $limit;

$year = "";

if(isset($_GET["year"]))
{
	$year = $_GET["year"];

}


if(isset($_POST['year'])) 
{
	$year=$_POST['year'];
} 

	$result = mysqli_query($con,"SELECT * FROM register where year='$year' ORDER BY s_no ASC LIMIT $start_from, $limit");

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand" href="#" style="color: #034EA2; font-family: Helvetica Black,sans-serif; font-weight:bold;"> SAMSUNG </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
          
          <li class="nav-item">
            <a class="nav-link" href="Devices.php">Register Devices</a>
          </li> 

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Update Devices Status
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="last.php"> Last User & Last Location </a>
              <a class="dropdown-item" href="update.php"> Time Period </a>
            </div>
          </li> 

          <li class="nav-item dropdown active">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Search By
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="all.php"> All </a>
              <a class="dropdown-item" href="sample.php"> Sample ID </a>
              <a class="dropdown-item" href="devicetype.php"> Device Type </a>  
              <a class="dropdown-item" href="size.php"> Size </a>
              <a class="dropdown-item" href="model.php"> Model </a>
              <a class="dropdown-item" href="year.php"> Year </a>
            </div>
          </li>

          
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             Delete device record
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="delete.php"> delete record </a>
            </div>
          </li> 


        </ul>

         <div class="navbar-collapse collapse w-50 order-3 dual-collapse2">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
            <a class="nav-link" href="logout.php">Logout</a>
          </li>
            </ul>
          </div>
        </ul>
      </div>
    </nav>
<center>


	<div class="container">
		<br><br>
			<form action="" method="POST">
				<label> Year :</label>
				<input type="text" name="year" placeholder="Year">
				<input type="submit" name="search" class="btn" value="search">
			</form>
      <br>


           	<table class="table table-bordered table-striped">
				<tr>
					<th> S_No </th>
					<th> Sample </th>
			        <th> Device Type </th>
			        <th> Model </th>
			        <th> Year </th>
			        <th> Size </th>
		         	<th> Owner </th>
			        <th> Last_User </th>
			        <th> Last_Location </th>
		        	<th> Period </th>
		        	<th> Start_Date </th>
		        	<th> End_Date </th>
		        	<th> Status </th>
		         	<th> Remarks </th>
		        </tr> <br>

		    <thead>  
            <tbody>  
                	<?php 
                	$cur_date= date("Y-m-d");
                	$num=mysqli_num_rows($result);
                if($num > 0)
                {	 
                   while ($row = mysqli_fetch_array($result)) {
                   if($row['end_date']<$cur_date)
		        		{
		        			$Available= "Available";
		        		}
		        		else
		        		{
		        			$Available= "Not available";
		        		} 

                     ?>
                <tr>  
				<td><?php echo $row["s_no"]; ?></td>  
				<td><?php echo $row["sample"]; ?></td>
				<td><?php echo $row["dropdown"]; ?></td> 
				<td><?php echo $row['model']; ?></td>
			    <td><?php echo $row['year']; ?></td>
			    <td><?php echo $row['size']; ?></td>
			    <td><?php echo $row['owner']; ?></td>
			    <td><?php echo $row['user']; ?></td>
                <td><?php echo $row['loc']; ?></td>
			    <td><?php echo $row['period']; ?></td>
			    <td><?php echo $row['start_date']; ?></td>
			    <td><?php echo $row['end_date']; ?></td>
			   <td <?php if($Available == "Available"){echo "style='color: green;'";}else{echo "style='color: red;'";}?>><?php echo $Available ; ?></td>
	            <td><?php echo $row['remarks']; ?></td>
						
                </tr>
                <?php  
                }
                }
                else
		        {
		        		if($year != "")
		        		{
		        			echo '<script language="javascript">';
                        	echo 'alert("Invalid Year.");';
                        	echo '</script>';
                    	}
		        }     
                ?>  
            </tbody> 
            </thead>

            <?php

            $result_db = mysqli_query($con,"SELECT COUNT(s_no) FROM register"); 
            $row_db = mysqli_fetch_row($result_db);  
            $total_records = $row_db[0];  
            $total_pages = ceil($total_records / $limit); 
            /* echo  $total_pages; */
            $pagLink = "<ul class='pagination'>";  
            for ($i=1; $i<=$total_pages; $i++) {
              $pagLink .= "<li class='page-item'><a class='page-link' href='year.php?year=".$year."&page=".$i."'>".$i."</a></li>";	
              }
            echo $pagLink . "</ul>";  
            ?>
    

		       


	         </table>
    </div>
</center>

<div class="footer">
  <p> All Rights Reserved @ Samsung <br> For Queries Contact: p.samal@samsung.com

  </p>
</div>

<style>
.footer {
  
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
   height: 55px;
}
</style>
			

</body>
</html>