<?php

$con= mysqli_connect("localhost","root","","login");
$output = '';
if (isset($_POST["export_excel"])) {
 
 $sql="SELECT * FROM register ORDER by s_no DESC";
 $result=mysqli_query($con,$sql);
 if (mysqli_num_rows($result)>0) {

 	$output .= '

 	<table class="table table-bordered" bordered="1">
		<tr>
			<th> S_No </th>
			<th> Sample </th>
			<th> Device Type </th>
		</tr>
    ';
    while($row = mysqli_fetch_array($result))
    {
    	$output .='

    	<tr>
			<td> '.$row['s_no'].'</td>
			<td> '.$row['sample'].'</td>
			<td> '.$row['dropdown'].'</td>
			
		</tr>

    	';
    }
    $output .= '</table>';
    header("Content-Type: application/xls");
    header("Content-Disposition:attachment; filename=download.xls");
    echo $output;
 	# code...
 }

	# code...
}

?>